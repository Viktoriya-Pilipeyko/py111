class NewFooClass():
    
    def print_something(self):
        print('Hello World!')